<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>
<?php
extract( $arResult );
?>
<?php if((isset($_GET['id']))||(isset($_GET['ID']))){ 
foreach($infoList as $tableelem){
if($tableelem['id'] == $_GET['id']){	
?>
<div class="elm">
<img src="<?php echo $tableelem['imgfull']['src'];?>" />
<h2><?php echo $tableelem['infoname']; ?></h2>
<span class="small"><?php echo $tableelem['newsDate']; ?></span>
<div class="fulltext"><?php echo $tableelem['fulltext']; ?></div>
</div>
<br>
<div class="comments"><h3>Комментарии:</h3><br>
<div><h5>Оставить комментарий:</h5>
<form name="sendcomment" action="<?=$_SERVER["REQUEST_URI"]?>" method="POST">
<input type="hidden" name="newsid" value="<?php echo $tableelem['id']; ?>">
<input type="hidden" name="newsurl" value="<?=$_SERVER["REQUEST_URI"]?>">
<label>Ваше имя</label><br>
<input type="text" name="usrname"><br>
<label>Текст комментария</label><br>
<textarea name="commenttext"></textarea><br>
<input type="submit" title="Отправить">
</form>
</div><hr>
<?php foreach($tableelem['comments'] as $commentelem){ ?>
<div class="commentel"><h4><?php echo $commentelem['commentname']; ?></h4>
<div><?php echo $commentelem['commenttext']; ?></div><hr>
</div>
<?php } ?>
</div>
<?php }}} else {?>
<?php foreach($infoList as $tableelem){ ?>
<div class="elm">
<h2><a href="?id=<?php echo $tableelem['id']; ?>"><?php echo $tableelem['infoname']; ?></a></h2>
<img src="<?php echo $tableelem['imgprvw']['src'];?>" /><br>
<span class="small"><?php echo $tableelem['newsDate']; ?></span>
<div class="preview"><?php echo $tableelem['preview']; ?></div>
</div>
<?php }} ?>