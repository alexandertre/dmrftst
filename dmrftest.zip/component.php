<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if(!CModule::IncludeModule("iblock"))
{
    $this->AbortResultCache();
    ShowError('IBLOCK_MODULE_NOT_INSTALLED');
    return;
}



$cachePeriod = isset($arParams["CACHE_PERIOD"]) ? $arParams["CACHE_PERIOD"] : DEFAULT_CACHE_PERIOD;
$cacheId = 'dmrftest' . serialize( $_GET );
if ( $this->StartResultCache( $cachePeriod, $cacheId, 'new' ) ){
    $filter = array('IBLOCK_CODE' => $arParams["IBLOCK_CODE"], 'ACTIVE' => 'Y');
    if ( isset( $arParams['SHOW_FOR_INDEX'] ) ) {
        $filter['PROPERTY_in_index_VALUE'] = 'Y';
    }
    $infoDbRes = CIBlockElement::GetList(array('SORT' => 'ASC'), $filter );
    while ( $infoEl = $infoDbRes->GetNextElement() ) {
        $infoFields = $infoEl->GetFields();
        $infoProps = $infoEl->GetProperties();
		$newsDate = $infoFields['DATE_CREATE'];
		if (CModule::IncludeModule('highloadblock')) {
			 $ID = $arParams["HLBCODE"];
			  

    $hldata = Bitrix\Highloadblock\HighloadBlockTable::getById($ID)->fetch();
    $hlentity = Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hldata);
    $hlDataClass = $hldata["NAME"] . "Table";

				if((isset($_POST['usrname']))&&(isset($_POST['commenttext']))){
$username = $_POST['usrname'];
$usertext = $_POST['commenttext'];
$commnewsid = $_POST['newsid'];
$commnewsurl = $_POST['newsurl'];
$result = $hlDataClass::add(array(
      'UF_NAME'         => $username,
      'UF_FULL_DESCRIPTION'         => $usertext,
      'UF_FORLINK' => $commnewsid,
	  'UF_LINK' =>$commnewsurl
      ));
unset($_POST);	  
}
	
	
    $result = $hlDataClass::getList(array(
                "select" => array("ID", "UF_NAME", "UF_XML_ID", "UF_FORLINK", "UF_FULL_DESCRIPTION"), // Поля для выборки
                "order" => array("ID" => "DESC"),
                "filter" => array('UF_FORLINK' => $infoFields['ID']),
    ));
$commentsarray = array();
    while ($res = $result->fetch()) {
	 $commentsarray[] = array(
	 'commentid' => $res['ID'],
	 'commentname' => $res['UF_NAME'],
	 'commenttext' => $res['UF_FULL_DESCRIPTION'],
	 'commentnews	link' => $res['UF_FORLINK'],
	 );
    }
}
		
		
		
        $infoList[] = array(
			'id' => $infoFields['ID'],
			'infoname' => $infoFields['NAME'],
			'fulltext' => $infoFields['~DETAIL_TEXT'],
			'fulltext' => $infoFields['~DETAIL_TEXT'],
			'imgprvw' => CFile::ResizeImageGet($infoFields['PREVIEW_PICTURE'], Array("width" => 128, "height" => 128), BX_RESIZE_IMAGE_EXACT, false),
			'imgfull' => CFile::ResizeImageGet($infoFields['DETAIL_PICTURE'], Array("width" => 512, "height" => 512), BX_RESIZE_IMAGE_EXACT, false),
			'preview' => trim( $infoFields['~PREVIEW_TEXT'] ),
			'newsDate' => $newsDate,
			'comments' => $commentsarray
        );
    }
    $arResult = array( 'infoList' => $infoList );
    $this->IncludeComponentTemplate();

	

	
	
	
	
	
	}
?>
