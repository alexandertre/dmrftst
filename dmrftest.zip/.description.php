<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    "NAME" => "dmrftest",
    "DESCRIPTION" => "dmrftest",
    "ICON" => "/images/icon.gif",
    "CACHE_PATH" => "Y",
);

?>